<?php
/**
 * I wish more pepole were fluent in silence.
 */
